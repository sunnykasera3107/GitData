<?php foreach ($rows as $row_count => $row): ?>
	<h1 class="title promotion-title" id="page-title">
        >> <?php print strip_tags($row['title']);?>
    </h1>
	<div class="promotion-left">
		<?php print $row['body'];?>
	</div>
	<div class="promotion-right">
		<?php print $row['field_image'];?>
	</div>
<?php endforeach; ?>
