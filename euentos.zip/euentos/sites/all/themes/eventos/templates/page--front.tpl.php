<!--Main wrapper start-->
<section id="wrapper" class="outer_width">
  <!--header start-->
  <header id="header" class="outer_width">
    <!--top header start-->
    <section class="top-header outer_width">
      <div class="inner_width">
        <?php if($page['header_left']):?>
          <?php print drupal_render($page['header_left']);?>
        <?php endif;?>
        <?php if($page['header_right']):?>
          <?php print drupal_render($page['header_right']);?>
        <?php endif;?>
      </div>    
    </section>
    <!--top header end-->
    <!--header middle start-->
    <section id="header_middle" class="outer_width">
      <div class="inner_width">
        <?php if ($logo): ?>
          <a href="<?php print $front_page; ?>" title="<?php print t('Home'); ?>" rel="home" id="logo" class="brand-logo">
            <img src="<?php print $logo; ?>" alt="<?php print t('Home'); ?>" />
          </a>
        <?php endif; ?>
      </div>    
    </section>
    <!--header middle end-->
    <!--header bottom start-->
    <section id="header_bottom" class="outer_width">
      <div class="inner_width">
        <!--main navigation start-->
        <nav id="main_navigation">
          <?php if ($main_menu): ?>
            <?php print theme('links__system_main_menu', array(
              'links' => $main_menu,
              'attributes' => array(
                'id' => 'main-menu-links',
                'class' => array('nav'),
                ),
              'heading' => array(
                'text' => t('Menu'),
                'level' => 'a',
                'class' => array('toggleMenu'),
                ),
                )); ?>
              <?php endif; ?>
            </nav>
            <!--main navigation end-->
          </div>
        </section>    
        <!--header bottom start-->
      </header>
      <!--header end-->
      <!--Slider start-->
      <?php if($page['slider']):?>
        <section id="slider" class="outer_width">
          <!-- Place somewhere in the <body> of your page -->
          <?php print drupal_render($page['slider']); ?>
        </section>
        <!--Slider end-->
      <?php endif;?>
      <!--middle container start-->
      <section id="middle_container" class="outer_width">
        <!--pramotion section start-->
        <section class="promotion-sec-wrap outer_width">
          <div class="inner_width">
            <?php if ($messages): ?>
              <div id="messages"><div class="section clearfix">
                <?php print $messages; ?>
              </div></div> <!-- /.section, /#messages -->
            <?php endif; ?>
            <div id="main-wrapper" class="clearfix"><div id="main" class="clearfix">
              <?php if ($breadcrumb): ?>
                <div id="breadcrumb"><?php //print $breadcrumb; ?></div>
              <?php endif; ?>
              <?php if ($page['sidebar_first']): ?>
                <div id="sidebar-first" class="column sidebar"><div class="section">
                  <?php print render($page['sidebar_first']); ?>
                </div></div> <!-- /.section, /#sidebar-first -->
              <?php endif; ?>
              <div id="content" class="column"><div class="section">
                <a id="main-content"></a>
                <?php print render($title_prefix); ?>
                <?php if ($title): ?>
                  <h1 class="title promotion-title" id="page-title">
                    >> <?php print $title; ?>
                  </h1>
                <?php endif; ?>
                <?php print render($title_suffix); ?>
                <?php if ($tabs): ?>
                  <div class="tabs">
                    <?php print render($tabs); ?>
                  </div>
                <?php endif; ?>
                <?php if ($action_links): ?>
                  <ul class="action-links">
                    <?php print render($action_links); ?>
                  </ul>
                <?php endif; ?>
                <?php print render($page['content']); ?>
                <?php print $feed_icons; ?>
              </div></div> <!-- /.section, /#content -->
              <?php if ($page['sidebar_second']): ?>
                <div id="sidebar-second" class="column sidebar"><div class="section">
                  <?php print render($page['sidebar_second']); ?>
                </div></div> <!-- /.section, /#sidebar-second -->
              <?php endif; ?> 
            </div>
          </section>
          <!--pramotion section end-->
          <!--product sec start-->
          <section class="product-sec-wrap outer_width">
            <div class="inner_width">
              <!--product start-->
              <?php if ($page['triptych_first']):?>
                <?php print drupal_render($page['triptych_first']);?>
              <?php endif;?>
              <!--product end-->
              <!--product start-->
              <?php if ($page['triptych_second']):?>
                <?php print drupal_render($page['triptych_second']);?>
              <?php endif;?>
              <!--product end-->
              <!--product start-->
              <?php if ($page['triptych_third']):?>
                <?php print drupal_render($page['triptych_third']);?>
              <?php endif;?>
              <!--product end-->
            </div>
          </section>
          <!--product sec end-->
        </section>
        <!--middle container end-->
        <!--footer start-->
        <footer id="footer" class="outer_width">
          <div class="inner_width">
            <!--footer top start-->
            <section class="footer-top outer_width">
              <?php if ($page['footer_firstcolumn']):?>
                <?php print drupal_render($page['footer_firstcolumn']);?>
              <?php endif;?>
              <?php if ($page['footer_secondcolumn']):?>
                <?php print drupal_render($page['footer_secondcolumn']);?>
              <?php endif;?>
              <?php if ($page['footer_thirdcolumn']):?>
                <?php print drupal_render($page['footer_thirdcolumn']);?>
              <?php endif;?>
            </section>
            <!--footer top end-->
            <!--footer bottom start-->
            <div class="footer-bottom outer_width">
              <?php if ($page['footer']):?>
                <?php print drupal_render($page['footer']);?>
              <?php endif;?>
            </div>
            <!--footer bottom end-->
          </div>
        </footer>
        <!--footer end-->
      </section>
      <!--Main wrapper end-->
<!--All Jquerys Files-->