<ul class="promotion-list">
  <?php foreach ($rows as $row_count => $row): ?>
    <li>
      <?php print $row['title'];?>
      <?php print $row['body'];?>
    </li>
  <?php endforeach; ?>
</ul>