(function($){
	$(function() {
		var pull 		= $('#top_pull');
			menu 		= $('#top_right_menu ul');
			li_a=menu.find("li a");
			menuHeight	= menu.height();
			$(pull).on('click', function(e) {
				e.preventDefault();
				menu.slideToggle();
				menu.toggleClass("slide_toggle");
			});
		  $(window).resize(function(){		  		  
		  var w = $(window).width();
			  if(w > 320 && menu.is(':hidden')) {
				  menu.removeAttr('style');
			  }		  		 
		  }); 
	});


	// Can also be used with $(document).ready()
	$(window).load(function() {
	  $('.flexslider').flexslider({
	    animation: "fade",
	    prevText: " ",
	    nextText: " "
	  });
	});
})(jQuery);