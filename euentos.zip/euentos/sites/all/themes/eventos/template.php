<?php

/**
 * Implementing hook_form_alter();
 * @param array $form;
 * @param array $form_state;
 */
function eventos_form_webform_client_form_5_alter(&$form, &$form_state){
	global $base_url;
	$form['submitted']['privacy_check']['#prefix'] = '<div class="private-policy-submit">';
	$form['actions']['submit']['#prefix'] = '<div class="submit-wrap">';
	$form['actions']['submit']['#attributes']['class'][] = 'submit-btn';
	$form['actions']['submit']['#suffix'] = '</div></div>';
}